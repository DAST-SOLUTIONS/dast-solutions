export { default as ParametresPage } from './ParametresPage'
