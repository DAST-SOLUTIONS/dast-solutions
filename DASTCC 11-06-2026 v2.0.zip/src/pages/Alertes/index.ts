// Pages Alertes - Index
export { default as AlertCenter } from './AlertCenter'
