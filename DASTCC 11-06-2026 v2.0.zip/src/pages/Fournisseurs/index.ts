// Pages Fournisseurs - Index
export { default as FournisseursModule } from './FournisseursModule'
