export { default as StorageManager } from './StorageManager'
