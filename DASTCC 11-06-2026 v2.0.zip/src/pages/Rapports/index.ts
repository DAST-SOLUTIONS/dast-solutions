// Pages Rapports - Index
export { default as ReportCenter } from './ReportCenter'
