export { default as DashboardBI } from './DashboardBI'
