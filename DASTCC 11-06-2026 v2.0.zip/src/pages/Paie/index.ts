/**
 * DAST Solutions - Phase 4: Module Paie
 * Exports pour Paie Standard et CCQ
 */

export { default as PayrollStandard } from './PayrollStandard'
export { default as PayrollCCQ } from './PayrollCCQ'
