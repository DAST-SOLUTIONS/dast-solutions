export { default as EquipesTravail } from './EquipesTravail'
